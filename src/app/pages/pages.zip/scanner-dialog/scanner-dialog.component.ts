// Updated scanner-dialog.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import Quagga from 'quagga';

@Component({
  selector: 'app-scanner-dialog',
  templateUrl: './scanner-dialog.component.html',
  styleUrls: ['./scanner-dialog.component.scss']
})
export class ScannerDialogComponent implements OnInit, OnDestroy {
  constructor(private dialogRef: MatDialogRef<ScannerDialogComponent>) {}

  ngOnInit(): void {
    this.initQuagga();
  }

  ngOnDestroy(): void {
    Quagga.stop();
  }

  initQuagga(): void {
    Quagga.init(
      {
        inputStream: {
          type: 'LiveStream',
          target: document.querySelector('#scannerVideo'), // Attach to the video element
          constraints: {
            facingMode: 'environment', // Use the back camera
          },
        },
        decoder: {
          readers: ['code_128_reader', 'ean_reader', 'ean_8_reader'], // Add barcode formats as needed
        },
      },
      (err) => {
        if (err) {
          console.error('Quagga initialization failed:', err);
          return;
        }
        console.log('Quagga initialized successfully');
        Quagga.start();
      }
    );
  
    Quagga.onDetected((data) => {
      console.log('Barcode detected:', data.codeResult.code);
      alert(`Barcode detected: ${data.codeResult.code}`);
      this.closeDialog();
    });
  }
  

  closeDialog(): void {
    Quagga.stop();
    this.dialogRef.close();
  }
}