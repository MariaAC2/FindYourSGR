import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-scanner-dialog',
  templateUrl: './scanner-dialog.component.html',
  styleUrls: ['./scanner-dialog.component.scss']
})
export class ScannerDialogComponent {
  @Output() scanComplete = new EventEmitter<string>();
  selectedDevice: MediaDeviceInfo | undefined;

  constructor() {}

  handleScanSuccess(result: string): void {
    console.log('Scan successful:', result);
    this.scanComplete.emit(result); // Emit the scanned result
  }

  closeScanner(): void {
    console.log('Closing scanner...');
    // Add logic to close the scanner or emit an event to the parent component
  }
}
