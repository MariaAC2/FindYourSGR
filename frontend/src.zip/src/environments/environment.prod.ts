export const environment = {
  firebase: {
    // add your Firebase config here
    databaseURL: "https://lab-isi-lasa-ma-default-rtdb.europe-west1.firebasedatabase.app/",
    apiKey: "AIzaSyDnR2JEzL4QuGVVJfhP5oQsKinDu-YUqQA",
    authDomain: "lab-isi-lasa-ma.firebaseapp.com",
    projectId: "lab-isi-lasa-ma",
    storageBucket: "lab-isi-lasa-ma.firebasestorage.app",
    messagingSenderId: "359420042783",
    appId: "1:359420042783:web:1286df0ae6530825bc3f2a",
    measurementId: "G-17VJJXQJ6P"
  },
  production: true
};
